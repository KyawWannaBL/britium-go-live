-- Restores backed-up V50 function definitions.
-- Additive V55 columns are intentionally retained to avoid destructive rollback.

begin;

do $rollback$
declare
  r record;
begin
  for r in
    select object_identity, definition
    from public.be_final_sync_lineage_v55_definition_backup
    where migration_id = 'FINAL_SYNC_CANONICAL_DATA_ENTRY_LINEAGE_V55_2026_07_31'
    order by object_identity
  loop
    execute r.definition;
  end loop;
end;
$rollback$;

commit;
