-- Run after: select public.be_final_sync_refresh_v50(null);

select jsonb_pretty(
  jsonb_build_object(
    'total_cases', count(*),
    'lineage_valid', count(*) filter (where lineage_valid),
    'lineage_invalid', count(*) filter (where not lineage_valid),
    'missing_data_entry_lineage', count(*) filter (
      where lineage_status = 'MISSING_DATA_ENTRY_LINEAGE'
    ),
    'ambiguous_data_entry_lineage', count(*) filter (
      where lineage_status = 'AMBIGUOUS_DATA_ENTRY_LINEAGE'
    ),
    'canonical_pickup_exposed_without_exact_data_entry', count(*) filter (
      where data_entry_match_count <> 1
        and pickup_id is not null
    ),
    'recorded_pickup_preserved_for_audit', count(*) filter (
      where recorded_pickup_id is not null
    ),
    'invalid_lineage_ready_or_certified', count(*) filter (
      where not lineage_valid
        and check_status in ('READY_TO_CERTIFY', 'CERTIFIED')
    ),
    'missing_lineage_open_variances', (
      select count(*)
      from public.be_final_sync_variances_v50 v
      where v.issue_code = 'MISSING_DATA_ENTRY_LINEAGE'
        and v.variance_status in ('OPEN', 'ASSIGNED')
    ),
    'merchant_mismatch_open_variances', (
      select count(*)
      from public.be_final_sync_variances_v50 v
      where v.issue_code = 'MERCHANT_CODE_MISMATCH'
        and v.variance_status in ('OPEN', 'ASSIGNED')
    )
  )
)
from public.be_final_sync_cases_v50;

select jsonb_pretty(
  public.be_final_sync_snapshot_v50('ALL', 1000)
) as snapshot;
