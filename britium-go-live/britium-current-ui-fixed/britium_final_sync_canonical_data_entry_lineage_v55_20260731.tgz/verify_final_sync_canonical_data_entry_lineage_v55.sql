-- Read-only definition verifier for Final Sync canonical Data Entry lineage V55.

with refresh_source as (
  select pg_get_functiondef(
    'public.be_final_sync_refresh_v50(text)'::regprocedure
  ) as definition
),
snapshot_source as (
  select pg_get_functiondef(
    'public.be_final_sync_snapshot_v50(text,integer)'::regprocedure
  ) as definition
),
case_columns as (
  select array_agg(column_name order by column_name) as names
  from information_schema.columns
  where table_schema = 'public'
    and table_name = 'be_final_sync_cases_v50'
),
backup_rows as (
  select count(*)::integer as row_count
  from public.be_final_sync_lineage_v55_definition_backup
  where migration_id = 'FINAL_SYNC_CANONICAL_DATA_ENTRY_LINEAGE_V55_2026_07_31'
)
select jsonb_pretty(
  jsonb_build_object(
    'backup_rows', (select row_count from backup_rows),
    'parser_exists', to_regprocedure('public.be_operational_id_merchant_code(text)') is not null,
    'refresh_exact_data_entry_join', (
      select position(
        'upper(btrim(d.delivery_way_id)) = upper(btrim(m.delivery_way_id))'
        in definition
      ) > 0
      from refresh_source
    ),
    'refresh_uses_canonical_pickup_way_id', (
      select position('de.row_json ->> ''pickup_way_id''' in definition) > 0
      from refresh_source
    ),
    'refresh_preserves_recorded_pickup', (
      select position('recorded_pickup_id' in definition) > 0
      from refresh_source
    ),
    'refresh_has_missing_lineage_variance', (
      select position('MISSING_DATA_ENTRY_LINEAGE' in definition) > 0
      from refresh_source
    ),
    'refresh_has_merchant_mismatch_variance', (
      select position('MERCHANT_CODE_MISMATCH' in definition) > 0
      from refresh_source
    ),
    'refresh_has_no_max_pickup_aggregate', (
      select position('max(pickup_id)' in lower(definition)) = 0
      from refresh_source
    ),
    'refresh_build_marker_present', (
      select position(
        'FINAL_SYNC_CANONICAL_DATA_ENTRY_LINEAGE_V55_2026_07_31'
        in definition
      ) > 0
      from refresh_source
    ),
    'snapshot_build_marker_present', (
      select position(
        'FINAL_SYNC_CANONICAL_DATA_ENTRY_LINEAGE_V55_2026_07_31'
        in definition
      ) > 0
      from snapshot_source
    ),
    'snapshot_exposes_lineage_filters', (
      select position('LINEAGE_INVALID' in definition) > 0
      from snapshot_source
    ),
    'case_lineage_columns_present', (
      select array[
        'data_entry_match_count',
        'data_entry_row_id',
        'lineage_source',
        'lineage_status',
        'lineage_valid',
        'merchant_code',
        'pickup_merchant_code',
        'recorded_pickup_id',
        'way_merchant_code'
      ] <@ names
      from case_columns
    ),
    'certifier_lineage_guard_still_present', position(
      'be_way_pickup_lineage_match_v54'
      in pg_get_functiondef(
        'public.be_final_sync_certify_v50(text,text,text)'::regprocedure
      )
    ) > 0
  )
);
