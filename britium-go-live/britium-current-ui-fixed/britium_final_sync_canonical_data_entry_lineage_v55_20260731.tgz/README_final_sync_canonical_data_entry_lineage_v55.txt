BRITIUM PRODUCTION - FINAL SYNC CANONICAL DATA ENTRY LINEAGE V55

Purpose
-------
The active V50 refresh used be_wayplan_membership_v40.pickup_id as if it were
canonical lineage. The production audit found 45 membership rows and zero exact
Data Entry matches. This patch makes the exact normalized Data Entry Way row the
only canonical lineage source.

Safety behavior
---------------
- Does not modify be_wayplan_membership_v40.
- Does not modify be_data_entry_register_rows.
- Does not invent or infer Pickup IDs.
- Preserves the recorded Wayplan Pickup ID in recorded_pickup_id and snapshots.
- Sets canonical pickup_id to NULL when no exact Data Entry row exists.
- Opens MISSING_DATA_ENTRY_LINEAGE or other lineage variances.
- Prevents invalid lineage from reaching READY_TO_CERTIFY or CERTIFIED.
- Keeps the existing direct-RPC certification guard.

Expected current production result
----------------------------------
Because the supplied audit reported 45 membership rows and zero exact Data Entry
matches, the first full refresh is expected to classify all 45 as canonical
lineage unavailable. This is stricter than the earlier 44-row browser wrapper
classification and follows the specification that Data Entry is the canonical
source.

Run order
---------
1. 20260731_final_sync_canonical_data_entry_lineage_v55.sql
2. verify_final_sync_canonical_data_entry_lineage_v55.sql
3. select jsonb_pretty(public.be_final_sync_refresh_v50(null));
4. post_refresh_verify_final_sync_lineage_v55.sql

Do not run the rollback unless the migration itself caused a verified regression.
The rollback restores the three replaced V50 functions but intentionally retains
additive columns.

Frontend
--------
The local archive path printed by Git Bash is on the user's computer and is not
available in this environment until uploaded. Upload the generated
production-remediation-current-*.tgz archive for an exact current frontend patch.
