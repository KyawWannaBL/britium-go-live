-- BRITIUM PRODUCTION
-- Final Synchronization canonical Data Entry lineage V55
-- Additive migration. Does not modify Wayplan membership or Data Entry rows.
-- Build: FINAL_SYNC_CANONICAL_DATA_ENTRY_LINEAGE_V55_2026_07_31

begin;

create table if not exists public.be_final_sync_lineage_v55_definition_backup (
  migration_id text not null,
  object_identity text not null,
  definition text not null,
  backed_up_at timestamptz not null default now(),
  primary key (migration_id, object_identity)
);

insert into public.be_final_sync_lineage_v55_definition_backup(
  migration_id,
  object_identity,
  definition
)
select
  'FINAL_SYNC_CANONICAL_DATA_ENTRY_LINEAGE_V55_2026_07_31',
  x.object_identity,
  pg_get_functiondef(x.object_identity::regprocedure)
from (
  values
    ('public.be_final_sync_refresh_v50(text)'),
    ('public.be_final_sync_snapshot_v50(text,integer)'),
    ('public.be_final_sync_issue_label_v50(text)')
) as x(object_identity)
on conflict (migration_id, object_identity) do nothing;

create or replace function public.be_operational_id_merchant_code(p_value text)
returns text
language sql
immutable
set search_path = public, pg_temp
as $function$
  with parts as (
    select regexp_split_to_array(
      upper(btrim(coalesce(p_value, ''))),
      '-'
    ) as value_parts
  )
  select case
    when array_length(value_parts, 1) >= 3 then
      nullif(
        array_to_string(
          value_parts[2:array_length(value_parts, 1) - 1],
          '-'
        ),
        ''
      )
    else null
  end
  from parts;
$function$;

alter table public.be_final_sync_cases_v50
  add column if not exists recorded_pickup_id text,
  add column if not exists merchant_code text,
  add column if not exists way_merchant_code text,
  add column if not exists pickup_merchant_code text,
  add column if not exists lineage_valid boolean not null default false,
  add column if not exists lineage_status text not null default 'UNVERIFIED',
  add column if not exists lineage_source text not null default 'UNVERIFIED',
  add column if not exists data_entry_row_id uuid,
  add column if not exists data_entry_match_count integer not null default 0;

create index if not exists be_final_sync_cases_v50_lineage_idx
  on public.be_final_sync_cases_v50(lineage_valid, lineage_status, check_status);

create index if not exists be_final_sync_cases_v50_merchant_idx
  on public.be_final_sync_cases_v50(merchant_code, check_status);

create or replace function public.be_final_sync_issue_label_v50(p_code text)
returns text
language sql
immutable
set search_path = public, pg_temp
as $function$
  select case upper(coalesce(p_code, ''))
    when 'MISSING_WAREHOUSE_RECEIPT' then 'Warehouse receipt is missing'
    when 'WAREHOUSE_NOT_READY' then 'Warehouse record is not ready or contains an exception'
    when 'MISSING_DISPATCH_SCAN' then 'Mandatory Dispatch scan is missing or reversed'
    when 'WAYPLAN_NOT_DISPATCHED' then 'Wayplan or membership is not in a dispatched/final state'
    when 'MISSING_APPROVED_ROUTE' then 'Approved Mapbox route is missing'
    when 'RIDER_ROUTE_NOT_FINAL' then 'Rider route is not completed'
    when 'DELIVERY_NOT_FINAL' then 'Delivery stop has no final outcome'
    when 'FINANCE_NOT_CLEAR' then 'COD settlement is not financially clear'
    when 'CUSTOMER_CLOSURE_NOT_COMPLETE' then 'Customer communication is not closed'
    when 'DUPLICATE_ACTIVE_MEMBERSHIP' then 'Parcel appears in more than one active Wayplan'
    when 'OPEN_OPERATIONAL_ALERT' then 'An unresolved operational alert remains open'
    when 'RTO_ATTEMPT_MISMATCH' then 'RTO state does not agree with the failed-attempt ledger'
    when 'TIMESTAMP_ORDER_MISMATCH' then 'Department timestamps are out of workflow order'
    when 'MISSING_DATA_ENTRY_LINEAGE' then 'No exact canonical Data Entry row exists for this Way ID'
    when 'AMBIGUOUS_DATA_ENTRY_LINEAGE' then 'More than one normalized Data Entry row matches this Way ID'
    when 'MISSING_CANONICAL_PICKUP' then 'The exact Data Entry row has no canonical Pickup ID'
    when 'MISSING_CANONICAL_MERCHANT' then 'The exact Data Entry row has no canonical merchant code'
    when 'MERCHANT_CODE_MISMATCH' then 'Way ID, Pickup ID, and Data Entry merchant lineage do not agree'
    else initcap(replace(lower(coalesce(p_code, 'unknown variance')), '_', ' '))
  end;
$function$;

create or replace function public.be_final_sync_refresh_v50(p_scope text default null)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $function$
declare
  r record;
  v_scope text := nullif(btrim(coalesce(p_scope, '')), '');
  v_actor text := public.be_final_sync_actor_v50(null);
  v_issues text[];
  v_snapshot jsonb;
  v_old_snapshot jsonb;
  v_old_status text;
  v_old_certified_at timestamptz;
  v_case_status text;
  v_stale boolean;
  v_issue text;
  v_way_merchant_code text;
  v_pickup_merchant_code text;
  v_lineage_valid boolean;
  v_lineage_status text;
  v_lineage_source text;
  v_rows integer := 0;
  v_variances_opened integer := 0;
  v_variances_resolved integer := 0;
  v_lineage_mismatch_count integer := 0;
  v_data_entry_missing_count integer := 0;
  v_data_entry_ambiguous_count integer := 0;
  v_before_count integer;
begin
  if not public.be_final_sync_can_manage_v50() then
    raise exception 'Final synchronization refresh requires Operations Control, Supervisor, Admin, Auditor, or Compliance authority';
  end if;

  for r in
    select
      upper(btrim(m.delivery_way_id)) as delivery_way_id,
      m.wayplan_id,
      m.pickup_id as recorded_pickup_id,
      case
        when coalesce(de.match_count, 0) = 1
          then nullif(btrim(de.row_json ->> 'pickup_way_id'), '')
        else null
      end as pickup_id,
      case
        when coalesce(de.match_count, 0) = 1
          then upper(nullif(btrim(de.row_json ->> 'merchant_code'), ''))
        else null
      end as merchant_code,
      case
        when coalesce(de.match_count, 0) = 1
          then nullif(de.row_json ->> 'row_id', '')::uuid
        else null
      end as data_entry_row_id,
      coalesce(de.match_count, 0)::integer as data_entry_match_count,
      m.route_zone,
      m.membership_status,
      w.warehouse_status,
      w.updated_at as warehouse_updated_at,
      ds.scan_status as dispatch_scan_status,
      ds.scanned_at as dispatch_scanned_at,
      rv.review_status,
      rv.dispatched_at,
      rp.route_status,
      rp.route_version,
      rp.optimized_at,
      rr.run_status as rider_run_status,
      rr.completed_at as rider_completed_at,
      rs.stop_status as delivery_status,
      rs.result_at as delivery_result_at,
      rs.result_operation_id,
      f.settlement_status as finance_status,
      f.expected_cod,
      f.proof_status as finance_proof_status,
      f.settled_at as finance_settled_at,
      c.workflow_status as cs_status,
      c.contacted_at,
      c.closed_at as cs_closed_at,
      coalesce(am.active_memberships, 0)::integer as active_memberships,
      coalesce(oa.open_alert_count, 0)::integer as open_alert_count,
      coalesce(da.consecutive_failures, 0)::integer as consecutive_failures
    from public.be_wayplan_membership_v40 m
    left join lateral (
      select
        count(*)::integer as match_count,
        (jsonb_agg(
          to_jsonb(d)
          order by d.updated_at desc nulls last,
                   d.created_at desc nulls last,
                   d.row_id
        ) -> 0) as row_json
      from public.be_data_entry_register_rows d
      where upper(btrim(d.delivery_way_id)) = upper(btrim(m.delivery_way_id))
    ) de on true
    left join lateral (
      select wr.warehouse_status, wr.updated_at
      from public.be_warehouse_receipts_v36 wr
      where wr.delivery_way_id = m.delivery_way_id
      order by wr.updated_at desc nulls last
      limit 1
    ) w on true
    left join public.be_dispatch_scans_v39 ds
      on ds.delivery_way_id = m.delivery_way_id
    left join public.be_wayplan_review_v43 rv
      on rv.wayplan_id = m.wayplan_id
    left join public.be_wayplan_route_plans_v45 rp
      on rp.wayplan_id = m.wayplan_id
     and rp.route_status = 'READY'
    left join public.be_rider_route_runs_v46 rr
      on rr.wayplan_id = m.wayplan_id
    left join public.be_rider_route_stop_state_v46 rs
      on rs.wayplan_id = m.wayplan_id
     and rs.delivery_way_id = m.delivery_way_id
    left join public.be_finance_cod_settlements_v48 f
      on f.delivery_way_id = m.delivery_way_id
    left join public.be_cs_closure_v49 c
      on c.delivery_way_id = m.delivery_way_id
    left join lateral (
      select count(*) as active_memberships
      from public.be_wayplan_membership_v40 x
      where x.delivery_way_id = m.delivery_way_id
        and x.membership_status not in ('CANCELLED', 'COMPLETED', 'RTO')
    ) am on true
    left join lateral (
      select count(*) as open_alert_count
      from public.be_operational_alerts_v39 a
      where a.delivery_way_id = m.delivery_way_id
        and a.alert_status in ('OPEN', 'ACKNOWLEDGED')
    ) oa on true
    left join public.be_delivery_attempt_state_v39 da
      on da.delivery_way_id = m.delivery_way_id
    where v_scope is null
       or upper(btrim(m.delivery_way_id)) = upper(btrim(v_scope))
       or upper(btrim(m.wayplan_id)) = upper(btrim(v_scope))
       or upper(btrim(coalesce(m.pickup_id, ''))) = upper(btrim(v_scope))
       or (
         coalesce(de.match_count, 0) = 1
         and upper(btrim(coalesce(de.row_json ->> 'pickup_way_id', ''))) = upper(btrim(v_scope))
       )
    order by m.wayplan_id, m.delivery_way_id
  loop
    v_rows := v_rows + 1;
    v_issues := '{}'::text[];

    v_way_merchant_code := public.be_operational_id_merchant_code(r.delivery_way_id);
    v_pickup_merchant_code := public.be_operational_id_merchant_code(r.pickup_id);
    v_lineage_valid := false;
    v_lineage_source := 'DATA_ENTRY_EXACT';

    if r.data_entry_match_count = 0 then
      v_lineage_status := 'MISSING_DATA_ENTRY_LINEAGE';
      v_lineage_source := 'DATA_ENTRY_MISSING';
      v_issues := array_append(v_issues, 'MISSING_DATA_ENTRY_LINEAGE');
      v_data_entry_missing_count := v_data_entry_missing_count + 1;
    elsif r.data_entry_match_count > 1 then
      v_lineage_status := 'AMBIGUOUS_DATA_ENTRY_LINEAGE';
      v_lineage_source := 'DATA_ENTRY_AMBIGUOUS';
      v_issues := array_append(v_issues, 'AMBIGUOUS_DATA_ENTRY_LINEAGE');
      v_data_entry_ambiguous_count := v_data_entry_ambiguous_count + 1;
    elsif r.pickup_id is null then
      v_lineage_status := 'MISSING_CANONICAL_PICKUP';
      v_issues := array_append(v_issues, 'MISSING_CANONICAL_PICKUP');
    elsif r.merchant_code is null then
      v_lineage_status := 'MISSING_CANONICAL_MERCHANT';
      v_issues := array_append(v_issues, 'MISSING_CANONICAL_MERCHANT');
    elsif coalesce(
      public.be_way_pickup_lineage_match_v54(r.delivery_way_id, r.pickup_id),
      false
    )
      and v_way_merchant_code = v_pickup_merchant_code
      and v_way_merchant_code = upper(r.merchant_code)
    then
      v_lineage_valid := true;
      v_lineage_status := 'VALID';
    else
      v_lineage_status := 'MERCHANT_CODE_MISMATCH';
      v_issues := array_append(v_issues, 'MERCHANT_CODE_MISMATCH');
    end if;

    if not v_lineage_valid then
      v_lineage_mismatch_count := v_lineage_mismatch_count + 1;
    end if;

    if r.warehouse_status is null then
      v_issues := array_append(v_issues, 'MISSING_WAREHOUSE_RECEIPT');
    elsif coalesce(r.delivery_status, '') in ('FAILED', 'RTO', 'CANCELLED') then
      if r.warehouse_status not in ('WAREHOUSE_READY', 'WAREHOUSE_EXCEPTION') then
        v_issues := array_append(v_issues, 'WAREHOUSE_NOT_READY');
      end if;
    elsif r.warehouse_status <> 'WAREHOUSE_READY' then
      v_issues := array_append(v_issues, 'WAREHOUSE_NOT_READY');
    end if;

    if coalesce(r.dispatch_scan_status, '') <> 'SCANNED' then
      v_issues := array_append(v_issues, 'MISSING_DISPATCH_SCAN');
    end if;

    if coalesce(r.review_status, '') <> 'DISPATCHED'
       or coalesce(r.membership_status, '') not in ('DISPATCHED', 'COMPLETED', 'RTO', 'CANCELLED') then
      v_issues := array_append(v_issues, 'WAYPLAN_NOT_DISPATCHED');
    end if;

    if coalesce(r.route_status, '') <> 'READY' then
      v_issues := array_append(v_issues, 'MISSING_APPROVED_ROUTE');
    end if;

    if coalesce(r.rider_run_status, '') not in ('COMPLETED', 'COMPLETED_WITH_EXCEPTIONS') then
      v_issues := array_append(v_issues, 'RIDER_ROUTE_NOT_FINAL');
    end if;

    if coalesce(r.delivery_status, '') not in ('DELIVERED', 'FAILED', 'RTO', 'CANCELLED') then
      v_issues := array_append(v_issues, 'DELIVERY_NOT_FINAL');
    end if;

    if coalesce(r.delivery_status, '') = 'DELIVERED' then
      if coalesce(r.expected_cod, 0) > 0
         and coalesce(r.finance_status, '') <> 'SETTLED' then
        v_issues := array_append(v_issues, 'FINANCE_NOT_CLEAR');
      elsif coalesce(r.expected_cod, 0) <= 0
         and coalesce(r.finance_status, '') not in ('SETTLED', 'NOT_REQUIRED') then
        v_issues := array_append(v_issues, 'FINANCE_NOT_CLEAR');
      end if;
    end if;

    if coalesce(r.cs_status, '') <> 'CLOSED' then
      v_issues := array_append(v_issues, 'CUSTOMER_CLOSURE_NOT_COMPLETE');
    end if;

    if r.active_memberships > 1 then
      v_issues := array_append(v_issues, 'DUPLICATE_ACTIVE_MEMBERSHIP');
    end if;

    if r.open_alert_count > 0 then
      v_issues := array_append(v_issues, 'OPEN_OPERATIONAL_ALERT');
    end if;

    if coalesce(r.delivery_status, '') = 'RTO'
       and r.consecutive_failures < 3 then
      v_issues := array_append(v_issues, 'RTO_ATTEMPT_MISMATCH');
    end if;

    if (r.delivery_result_at is not null and r.dispatched_at is not null and r.delivery_result_at < r.dispatched_at)
       or (r.finance_settled_at is not null and r.delivery_result_at is not null and r.finance_settled_at < r.delivery_result_at)
       or (r.cs_closed_at is not null and r.delivery_result_at is not null and r.cs_closed_at < r.delivery_result_at)
       or (coalesce(r.expected_cod, 0) > 0 and r.cs_closed_at is not null and r.finance_settled_at is not null and r.cs_closed_at < r.finance_settled_at) then
      v_issues := array_append(v_issues, 'TIMESTAMP_ORDER_MISMATCH');
    end if;

    select coalesce(array_agg(distinct x order by x), '{}'::text[])
      into v_issues
    from unnest(v_issues) x;

    v_snapshot := jsonb_build_object(
      'delivery_way_id', r.delivery_way_id,
      'wayplan_id', r.wayplan_id,
      'pickup_id', r.pickup_id,
      'recorded_pickup_id', r.recorded_pickup_id,
      'merchant_code', r.merchant_code,
      'way_merchant_code', v_way_merchant_code,
      'pickup_merchant_code', v_pickup_merchant_code,
      'lineage_valid', v_lineage_valid,
      'lineage_status', v_lineage_status,
      'lineage_source', v_lineage_source,
      'data_entry_row_id', r.data_entry_row_id,
      'data_entry_match_count', r.data_entry_match_count,
      'membership_status', r.membership_status,
      'warehouse', jsonb_build_object('status', r.warehouse_status, 'updated_at', r.warehouse_updated_at),
      'dispatch', jsonb_build_object('scan_status', r.dispatch_scan_status, 'scanned_at', r.dispatch_scanned_at),
      'wayplan_review', jsonb_build_object('status', r.review_status, 'dispatched_at', r.dispatched_at),
      'route', jsonb_build_object('status', r.route_status, 'version', r.route_version, 'optimized_at', r.optimized_at),
      'rider_run', jsonb_build_object('status', r.rider_run_status, 'completed_at', r.rider_completed_at),
      'delivery', jsonb_build_object('status', r.delivery_status, 'result_at', r.delivery_result_at, 'operation_id', r.result_operation_id),
      'finance', jsonb_build_object('status', r.finance_status, 'expected_cod', coalesce(r.expected_cod, 0), 'proof_status', r.finance_proof_status, 'settled_at', r.finance_settled_at),
      'customer_service', jsonb_build_object('status', r.cs_status, 'contacted_at', r.contacted_at, 'closed_at', r.cs_closed_at),
      'active_memberships', r.active_memberships,
      'open_alert_count', r.open_alert_count,
      'consecutive_failures', r.consecutive_failures,
      'issues', to_jsonb(v_issues)
    );

    select source_snapshot, check_status, certified_at
      into v_old_snapshot, v_old_status, v_old_certified_at
    from public.be_final_sync_cases_v50
    where delivery_way_id = r.delivery_way_id;

    if cardinality(v_issues) > 0 then
      v_case_status := 'VARIANCE';
      v_stale := v_old_certified_at is not null;
    elsif v_old_status = 'CERTIFIED' and v_old_snapshot = v_snapshot then
      v_case_status := 'CERTIFIED';
      v_stale := false;
    else
      v_case_status := 'READY_TO_CERTIFY';
      v_stale := v_old_certified_at is not null
                 and v_old_snapshot is distinct from v_snapshot;
    end if;

    insert into public.be_final_sync_cases_v50 (
      delivery_way_id,
      wayplan_id,
      pickup_id,
      recorded_pickup_id,
      merchant_code,
      way_merchant_code,
      pickup_merchant_code,
      lineage_valid,
      lineage_status,
      lineage_source,
      data_entry_row_id,
      data_entry_match_count,
      route_zone,
      membership_status,
      warehouse_status,
      dispatch_scan_status,
      review_status,
      route_status,
      rider_run_status,
      delivery_status,
      finance_status,
      cs_status,
      expected_cod,
      open_alert_count,
      check_status,
      issue_codes,
      source_snapshot,
      certification_stale,
      last_refreshed_by,
      last_refreshed_at,
      updated_at
    ) values (
      r.delivery_way_id,
      r.wayplan_id,
      r.pickup_id,
      r.recorded_pickup_id,
      r.merchant_code,
      v_way_merchant_code,
      v_pickup_merchant_code,
      v_lineage_valid,
      v_lineage_status,
      v_lineage_source,
      r.data_entry_row_id,
      r.data_entry_match_count,
      r.route_zone,
      r.membership_status,
      r.warehouse_status,
      r.dispatch_scan_status,
      r.review_status,
      r.route_status,
      r.rider_run_status,
      r.delivery_status,
      r.finance_status,
      r.cs_status,
      coalesce(r.expected_cod, 0),
      r.open_alert_count,
      v_case_status,
      v_issues,
      v_snapshot,
      v_stale,
      v_actor,
      now(),
      now()
    )
    on conflict (delivery_way_id) do update set
      wayplan_id = excluded.wayplan_id,
      pickup_id = excluded.pickup_id,
      recorded_pickup_id = excluded.recorded_pickup_id,
      merchant_code = excluded.merchant_code,
      way_merchant_code = excluded.way_merchant_code,
      pickup_merchant_code = excluded.pickup_merchant_code,
      lineage_valid = excluded.lineage_valid,
      lineage_status = excluded.lineage_status,
      lineage_source = excluded.lineage_source,
      data_entry_row_id = excluded.data_entry_row_id,
      data_entry_match_count = excluded.data_entry_match_count,
      route_zone = excluded.route_zone,
      membership_status = excluded.membership_status,
      warehouse_status = excluded.warehouse_status,
      dispatch_scan_status = excluded.dispatch_scan_status,
      review_status = excluded.review_status,
      route_status = excluded.route_status,
      rider_run_status = excluded.rider_run_status,
      delivery_status = excluded.delivery_status,
      finance_status = excluded.finance_status,
      cs_status = excluded.cs_status,
      expected_cod = excluded.expected_cod,
      open_alert_count = excluded.open_alert_count,
      check_status = excluded.check_status,
      issue_codes = excluded.issue_codes,
      source_snapshot = excluded.source_snapshot,
      certification_stale = excluded.certification_stale,
      last_refreshed_by = excluded.last_refreshed_by,
      last_refreshed_at = excluded.last_refreshed_at,
      updated_at = now();

    foreach v_issue in array v_issues loop
      select count(*)
        into v_before_count
      from public.be_final_sync_variances_v50
      where delivery_way_id = r.delivery_way_id
        and issue_code = v_issue
        and variance_status in ('OPEN', 'ASSIGNED');

      insert into public.be_final_sync_variances_v50 (
        delivery_way_id,
        wayplan_id,
        issue_code,
        issue_summary,
        variance_status,
        detected_at,
        last_detected_at,
        detected_snapshot,
        updated_at
      )
      select
        r.delivery_way_id,
        r.wayplan_id,
        v_issue,
        public.be_final_sync_issue_label_v50(v_issue),
        'OPEN',
        now(),
        now(),
        v_snapshot,
        now()
      where v_before_count = 0;

      if v_before_count = 0 then
        v_variances_opened := v_variances_opened + 1;
      else
        update public.be_final_sync_variances_v50
        set last_detected_at = now(),
            detected_snapshot = v_snapshot,
            updated_at = now()
        where delivery_way_id = r.delivery_way_id
          and issue_code = v_issue
          and variance_status in ('OPEN', 'ASSIGNED');
      end if;
    end loop;

    with resolved as (
      update public.be_final_sync_variances_v50
      set variance_status = 'RESOLVED',
          resolved_by = v_actor,
          resolved_at = now(),
          resolution_note = coalesce(
            resolution_note,
            'Automatically cleared by canonical Data Entry refresh'
          ),
          updated_at = now()
      where delivery_way_id = r.delivery_way_id
        and variance_status in ('OPEN', 'ASSIGNED')
        and not (issue_code = any(v_issues))
      returning 1
    )
    select count(*) into v_before_count from resolved;

    v_variances_resolved := v_variances_resolved + v_before_count;

    update public.be_final_sync_cases_v50 c
    set open_variance_count = (
          select count(*)::integer
          from public.be_final_sync_variances_v50 v
          where v.delivery_way_id = c.delivery_way_id
            and v.variance_status in ('OPEN', 'ASSIGNED')
        ),
        updated_at = now()
    where c.delivery_way_id = r.delivery_way_id;

    if v_old_snapshot is distinct from v_snapshot then
      insert into public.be_final_sync_events_v50(
        delivery_way_id,
        wayplan_id,
        event_type,
        actor,
        payload
      ) values (
        r.delivery_way_id,
        r.wayplan_id,
        'LINEAGE_REFRESHED_V55',
        v_actor,
        jsonb_build_object(
          'before', v_old_snapshot,
          'after', v_snapshot,
          'build', 'FINAL_SYNC_CANONICAL_DATA_ENTRY_LINEAGE_V55_2026_07_31'
        )
      );
    end if;
  end loop;

  insert into public.be_final_sync_events_v50(event_type, actor, payload)
  values (
    'CANONICAL_REFRESH',
    v_actor,
    jsonb_build_object(
      'scope', v_scope,
      'rows_refreshed', v_rows,
      'variances_opened', v_variances_opened,
      'variances_resolved', v_variances_resolved,
      'lineage_mismatch_count', v_lineage_mismatch_count,
      'data_entry_missing_count', v_data_entry_missing_count,
      'data_entry_ambiguous_count', v_data_entry_ambiguous_count,
      'build', 'FINAL_SYNC_CANONICAL_DATA_ENTRY_LINEAGE_V55_2026_07_31'
    )
  );

  return jsonb_build_object(
    'ok', true,
    'scope', v_scope,
    'rows_refreshed', v_rows,
    'variances_opened', v_variances_opened,
    'variances_resolved', v_variances_resolved,
    'lineage_mismatch_count', v_lineage_mismatch_count,
    'data_entry_missing_count', v_data_entry_missing_count,
    'data_entry_ambiguous_count', v_data_entry_ambiguous_count,
    'refreshed_by', v_actor,
    'refreshed_at', now(),
    'build', 'FINAL_SYNC_CANONICAL_DATA_ENTRY_LINEAGE_V55_2026_07_31'
  );
end;
$function$;

create or replace function public.be_final_sync_snapshot_v50(
  p_filter text default 'ALL',
  p_limit integer default 500
)
returns jsonb
language sql
stable
security definer
set search_path = public, pg_temp
as $function$
  with params as (
    select
      upper(coalesce(nullif(btrim(p_filter), ''), 'ALL')) as filter_value,
      greatest(1, least(coalesce(p_limit, 500), 2000)) as row_limit
  ),
  filtered as (
    select c.*
    from public.be_final_sync_cases_v50 c, params p
    where p.filter_value = 'ALL'
       or c.check_status = p.filter_value
       or c.lineage_status = p.filter_value
       or p.filter_value = any(c.issue_codes)
       or (p.filter_value = 'LINEAGE_INVALID' and not c.lineage_valid)
       or (p.filter_value = 'LINEAGE_VALID' and c.lineage_valid)
  ),
  limited as (
    select *
    from filtered
    order by
      case check_status
        when 'VARIANCE' then 1
        when 'READY_TO_CERTIFY' then 2
        when 'PENDING' then 3
        when 'CERTIFIED' then 4
        else 5
      end,
      updated_at desc,
      delivery_way_id
    limit (select row_limit from params)
  ),
  row_payload as (
    select
      to_jsonb(l) || jsonb_build_object(
        'open_variances', coalesce((
          select jsonb_agg(to_jsonb(v) order by v.detected_at, v.id)
          from public.be_final_sync_variances_v50 v
          where v.delivery_way_id = l.delivery_way_id
            and v.variance_status in ('OPEN', 'ASSIGNED')
        ), '[]'::jsonb)
      ) as row_json
    from limited l
  ),
  summary as (
    select jsonb_build_object(
      'rows', count(*)::integer,
      'pending', count(*) filter (where check_status = 'PENDING')::integer,
      'variance', count(*) filter (where check_status = 'VARIANCE')::integer,
      'ready_to_certify', count(*) filter (where check_status = 'READY_TO_CERTIFY')::integer,
      'certified', count(*) filter (where check_status = 'CERTIFIED')::integer,
      'stale_certifications', count(*) filter (where certification_stale)::integer,
      'open_variances', coalesce(sum(open_variance_count), 0)::integer,
      'expected_cod', coalesce(sum(expected_cod), 0),
      'lineage_valid', count(*) filter (where lineage_valid)::integer,
      'lineage_invalid', count(*) filter (where not lineage_valid)::integer,
      'data_entry_missing', count(*) filter (where lineage_status = 'MISSING_DATA_ENTRY_LINEAGE')::integer,
      'data_entry_ambiguous', count(*) filter (where lineage_status = 'AMBIGUOUS_DATA_ENTRY_LINEAGE')::integer
    ) as value
    from filtered
  )
  select jsonb_build_object(
    'ok', true,
    'build', 'FINAL_SYNC_CANONICAL_DATA_ENTRY_LINEAGE_V55_2026_07_31',
    'filter', (select filter_value from params),
    'workflow', 'DATA ENTRY LINEAGE -> CANONICAL REFRESH -> VARIANCE RESOLUTION -> CERTIFIED FOR REPORTING',
    'summary', (select value from summary),
    'rows', coalesce((select jsonb_agg(row_json) from row_payload), '[]'::jsonb),
    'issue_catalog', jsonb_build_array(
      jsonb_build_object('code', 'MISSING_DATA_ENTRY_LINEAGE', 'label', public.be_final_sync_issue_label_v50('MISSING_DATA_ENTRY_LINEAGE')),
      jsonb_build_object('code', 'AMBIGUOUS_DATA_ENTRY_LINEAGE', 'label', public.be_final_sync_issue_label_v50('AMBIGUOUS_DATA_ENTRY_LINEAGE')),
      jsonb_build_object('code', 'MISSING_CANONICAL_PICKUP', 'label', public.be_final_sync_issue_label_v50('MISSING_CANONICAL_PICKUP')),
      jsonb_build_object('code', 'MISSING_CANONICAL_MERCHANT', 'label', public.be_final_sync_issue_label_v50('MISSING_CANONICAL_MERCHANT')),
      jsonb_build_object('code', 'MERCHANT_CODE_MISMATCH', 'label', public.be_final_sync_issue_label_v50('MERCHANT_CODE_MISMATCH')),
      jsonb_build_object('code', 'MISSING_WAREHOUSE_RECEIPT', 'label', public.be_final_sync_issue_label_v50('MISSING_WAREHOUSE_RECEIPT')),
      jsonb_build_object('code', 'WAREHOUSE_NOT_READY', 'label', public.be_final_sync_issue_label_v50('WAREHOUSE_NOT_READY')),
      jsonb_build_object('code', 'MISSING_DISPATCH_SCAN', 'label', public.be_final_sync_issue_label_v50('MISSING_DISPATCH_SCAN')),
      jsonb_build_object('code', 'WAYPLAN_NOT_DISPATCHED', 'label', public.be_final_sync_issue_label_v50('WAYPLAN_NOT_DISPATCHED')),
      jsonb_build_object('code', 'MISSING_APPROVED_ROUTE', 'label', public.be_final_sync_issue_label_v50('MISSING_APPROVED_ROUTE')),
      jsonb_build_object('code', 'RIDER_ROUTE_NOT_FINAL', 'label', public.be_final_sync_issue_label_v50('RIDER_ROUTE_NOT_FINAL')),
      jsonb_build_object('code', 'DELIVERY_NOT_FINAL', 'label', public.be_final_sync_issue_label_v50('DELIVERY_NOT_FINAL')),
      jsonb_build_object('code', 'FINANCE_NOT_CLEAR', 'label', public.be_final_sync_issue_label_v50('FINANCE_NOT_CLEAR')),
      jsonb_build_object('code', 'CUSTOMER_CLOSURE_NOT_COMPLETE', 'label', public.be_final_sync_issue_label_v50('CUSTOMER_CLOSURE_NOT_COMPLETE')),
      jsonb_build_object('code', 'DUPLICATE_ACTIVE_MEMBERSHIP', 'label', public.be_final_sync_issue_label_v50('DUPLICATE_ACTIVE_MEMBERSHIP')),
      jsonb_build_object('code', 'OPEN_OPERATIONAL_ALERT', 'label', public.be_final_sync_issue_label_v50('OPEN_OPERATIONAL_ALERT')),
      jsonb_build_object('code', 'RTO_ATTEMPT_MISMATCH', 'label', public.be_final_sync_issue_label_v50('RTO_ATTEMPT_MISMATCH')),
      jsonb_build_object('code', 'TIMESTAMP_ORDER_MISMATCH', 'label', public.be_final_sync_issue_label_v50('TIMESTAMP_ORDER_MISMATCH'))
    ),
    'generated_at', now()
  );
$function$;

grant execute on function public.be_operational_id_merchant_code(text)
  to authenticated, service_role;

grant execute on function public.be_final_sync_refresh_v50(text)
  to authenticated, service_role;

grant execute on function public.be_final_sync_snapshot_v50(text, integer)
  to authenticated, service_role;

comment on function public.be_final_sync_refresh_v50(text) is
  'Canonical Final Sync refresh using exact normalized Data Entry delivery_way_id lineage. Build FINAL_SYNC_CANONICAL_DATA_ENTRY_LINEAGE_V55_2026_07_31.';

comment on function public.be_final_sync_snapshot_v50(text, integer) is
  'Final Sync snapshot with canonical lineage fields. Build FINAL_SYNC_CANONICAL_DATA_ENTRY_LINEAGE_V55_2026_07_31.';

commit;
